const http = require('http');
const fs = require('fs');
const ct = fs.readFileSync(__dirname + '/tg_status_bot.js', 'utf8');
const body = JSON.stringify({fn:'tg_status_bot.js', ct});
const req = http.request({
  hostname:'localhost', port:3001, path:'/write-file',
  method:'POST',
  headers:{'Content-Type':'application/json','Content-Length':Buffer.byteLength(body)}
}, res => {
  let d=''; res.on('data',c=>d+=c);
  res.on('end',()=>{ console.log('결과:', d); process.exit(0); });
});
req.on('error', e => { console.error('오류:', e.message); process.exit(1); });
req.write(body); req.end();
