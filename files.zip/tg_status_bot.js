/**
 * tg_status_bot.js v5
 * 어드민: status=3 (배송준비)
 * 곳간: 로그인 파라미터 수정
 */
require('dotenv').config({ path: require('path').join(__dirname, '.env') });
const https = require('https');
const http  = require('http');

const TG_TOKEN = '8796752509:AAFX54QxpY0SCXxAwpOXqqxVrKEvlZhSNKc';
const TG_CHAT  = '6097520392';
const ADMIN_HOST = 'dongnaegotgan.adminplus.co.kr';
const ADMIN_URL  = `https://${ADMIN_HOST}/admin/`;
const ADMIN_ID   = process.env.ADMIN_ID || 'dongnaegotgan';
const ADMIN_PW   = process.env.ADMIN_PW || 'rhtrks12!@';
const FG_HOST       = 'dongnaegotgan.flexgate.co.kr';
const FG_LOGIN_HOST = 'intro.flexgate.co.kr';
const FG_ID  = process.env.FG_ID  || 'dongnaegotgan';
const FG_PW  = process.env.FG_PW  || 'rhtrks12!@';

function log(m) { console.log(`[${new Date().toLocaleTimeString('ko-KR')}] ${m}`); }
function won(n) { return Number(n||0).toLocaleString('ko-KR') + '원'; }

function req(options, body = null) {
  return new Promise((resolve, reject) => {
    const mod = options.hostname === 'localhost' ? http : https;
    const r = mod.request(options, res => {
      let data = '';
      res.on('data', d => data += d);
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: data }));
    });
    r.on('error', reject);
    if (body) r.write(body);
    r.end();
  });
}
function parseCookies(arr) {
  const c = {};
  (arr||[]).forEach(s => {
    const [kv] = s.split(';'); const [k,v] = kv.split('=');
    if(k) c[k.trim()]=(v||'').trim();
  });
  return c;
}
function cookieStr(c) { return Object.entries(c).map(([k,v])=>`${k}=${v}`).join('; '); }

async function tgSend(msg, chatId = TG_CHAT) {
  const body = JSON.stringify({ chat_id: chatId, text: msg, parse_mode: 'HTML' });
  await req({ hostname: 'api.telegram.org', path: `/bot${TG_TOKEN}/sendMessage`,
    method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) }
  }, body).catch(()=>{});
}
async function tgGetUpdates(offset) {
  const res = await req({ hostname: 'api.telegram.org',
    path: `/bot${TG_TOKEN}/getUpdates?offset=${offset}&timeout=20&limit=10`, method: 'GET'
  }).catch(()=>null);
  if (!res) return [];
  try { const d = JSON.parse(res.body); return d.ok ? d.result : []; } catch { return []; }
}

// ── 어드민 ───────────────────────────────────────────────
let adminCookies = {}, adminLoginTime = 0;
async function adminLogin() {
  const body = new URLSearchParams({ id: ADMIN_ID, pw: ADMIN_PW, mode: 'login' }).toString();
  const res = await req({ hostname: ADMIN_HOST, path: '/admin/login.php', method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded',
      'Content-Length': Buffer.byteLength(body), 'Referer': ADMIN_URL, 'User-Agent': 'Mozilla/5.0' }
  }, body);
  let c = parseCookies(res.headers['set-cookie']);
  if (!Object.keys(c).length && res.headers['location']) {
    const r2 = await req({ hostname: ADMIN_HOST, path: res.headers['location'],
      method: 'GET', headers: { 'User-Agent': 'Mozilla/5.0' } });
    c = parseCookies(r2.headers['set-cookie']);
  }
  adminCookies = c; adminLoginTime = Date.now();
}
async function ensureAdmin() {
  if (Date.now() - adminLoginTime < 20*60*1000 && Object.keys(adminCookies).length) return;
  await adminLogin();
}

async function getAdminOrders() {
  await ensureAdmin();
  const today = new Date().toISOString().slice(0, 10);

  // stats로 건수 (spnNew5 = 주문접수)
  let orderCount = 0;
  try {
    const sr = await req({ hostname: ADMIN_HOST, path: '/admin/xml/real.stats.json.php', method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Content-Length': 0,
        'Cookie': cookieStr(adminCookies), 'Referer': ADMIN_URL,
        'User-Agent': 'Mozilla/5.0', 'X-Requested-With': 'XMLHttpRequest' }
    }, '');
    const stats = JSON.parse(sr.body);
    orderCount = parseInt(stats.spnNew5) || 0;
  } catch(e) { log(`stats 오류: ${e.message}`); }

  // status=3 (배송준비) 주문목록
  const prodMap = {};
  let totalAmount = 0;

  const params = new URLSearchParams({
    proc: 'json', mod: 'order', actpage: 'od.list.bd',
    status: '3',
    datefld: 'b.regdate',
    sdate: JSON.stringify({ start: today, end: today }),
    bizgrp: 'all', searchtype: 'all', searchval: '',
    _search: 'false', rows: '500', page: '1', sidx: 'regdate', sord: 'desc'
  });

  try {
    const res = await req({ hostname: ADMIN_HOST,
      path: `/admin/order/json/od.list.bd.php?${params}`, method: 'GET',
      headers: { 'Cookie': cookieStr(adminCookies), 'Referer': ADMIN_URL,
        'User-Agent': 'Mozilla/5.0', 'X-Requested-With': 'XMLHttpRequest' }
    });
    const data = JSON.parse(res.body);
    const rows = data.rows || [];
    const cnt = parseInt(data.records) || rows.length;
    log(`  [어드민 status=3] ${cnt}건`);

    rows.forEach(row => {
      const cell = Array.isArray(row.cell) ? row.cell : [];
      cell.forEach((c, idx) => {
        if (typeof c !== 'string') return;
        const text = c.replace(/<[^>]+>/g, '').replace(/\s+/g,' ').trim();

        // 상품명 + 수량 패턴들
        const patterns = [
          /^(.{2,40}?)\s+(\d+)개$/,
          /^(.{2,40}?)\/\s*(\d+)개$/,
          /^(.{2,40}?)\s+(\d+)개\s*$/m,
        ];
        for (const p of patterns) {
          const m = text.match(p);
          if (m && m[1].length >= 2) {
            const name = m[1].trim();
            const qty  = parseInt(m[2]);
            if (qty > 0 && qty < 1000) {
              prodMap[name] = (prodMap[name] || 0) + qty;
            }
          }
        }

        // 금액 파싱 (결제금액 컬럼 - 보통 idx 7~10 사이)
        if (idx >= 5 && idx <= 12) {
          const clean = text.replace(/,/g,'');
          const v = parseInt(clean);
          if (!isNaN(v) && v >= 5000 && v <= 500000) {
            totalAmount += v;
          }
        }
      });
    });
  } catch(e) { log(`리스트 오류: ${e.message}`); }

  return { orderCount, prodMap, totalAmount };
}

// ── flexgate ─────────────────────────────────────────────
let fgCookies = {}, fgLoginTime = 0;
async function fgLogin() {
  // dongnaegotgan.flexgate.co.kr 직접 로그인 시도
  const loginAttempts = [
    { host: FG_HOST, path: '/Mypage/LoginAjax',
      body: new URLSearchParams({ mb_id: FG_ID, mb_pw: FG_PW }).toString() },
    { host: FG_HOST, path: '/Mypage/Login',
      body: new URLSearchParams({ mb_id: FG_ID, mb_pw: FG_PW }).toString() },
    { host: FG_LOGIN_HOST, path: '/Mypage/Login',
      body: new URLSearchParams({ mb_id: FG_ID, mb_pw: FG_PW }).toString() },
    { host: FG_LOGIN_HOST, path: '/Mypage/Login',
      body: new URLSearchParams({ id: FG_ID, pw: FG_PW }).toString() },
  ];

  let bestCookies = {};
  for (const attempt of loginAttempts) {
    try {
      const res = await req({ hostname: attempt.host, path: attempt.path, method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded',
          'Content-Length': Buffer.byteLength(attempt.body), 'User-Agent': 'Mozilla/5.0',
          'Referer': `https://${attempt.host}${attempt.path}`,
          'X-Requested-With': 'XMLHttpRequest' }
      }, attempt.body);

      const c = parseCookies(res.headers['set-cookie']);
      log(`  [곳간 로그인 ${attempt.host}${attempt.path}] status=${res.status}, cookies=${JSON.stringify(Object.keys(c))}, body=${res.body.slice(0,80)}`);

      // 리다이렉트 따라가며 쿠키 수집
      let cookies = { ...c };
      let redirect = res.headers['location']; let hop = 0;
      while (redirect && hop < 5) {
        const isExt = redirect.startsWith('http');
        const url = isExt ? new URL(redirect) : null;
        const r2 = await req({
          hostname: url ? url.hostname : FG_HOST,
          path: url ? (url.pathname + url.search) : redirect,
          method: 'GET', headers: { 'Cookie': cookieStr(cookies), 'User-Agent': 'Mozilla/5.0' }
        });
        Object.assign(cookies, parseCookies(r2.headers['set-cookie']));
        redirect = r2.headers['location']; hop++;
      }

      // ck_user 이외의 의미있는 세션쿠키 체크
      const sessionKeys = Object.keys(cookies).filter(k => !['ck_user','PHPSESSID'].includes(k));
      if (Object.keys(cookies).length > 1 || sessionKeys.length > 0) {
        bestCookies = cookies;
        log(`  [곳간 로그인 성공] 쿠키: ${JSON.stringify(Object.keys(cookies))}`);
        break;
      }
      if (Object.keys(cookies).length > Object.keys(bestCookies).length) {
        bestCookies = cookies;
      }
    } catch(e) { log(`  [곳간] ${attempt.path} 오류: ${e.message}`); }
  }

  fgCookies = bestCookies;
  fgLoginTime = Date.now();
  log(`  [곳간 최종쿠키] ${JSON.stringify(Object.keys(fgCookies))}`);
}
async function ensureFg() {
  if (Date.now() - fgLoginTime < 20*60*1000 && Object.keys(fgCookies).length) return;
  await fgLogin();
}

async function getGotganOrders() {
  await ensureFg();

  const paths = [
    '/NewOrder/deal01?order_status=10&formtype=A&pagesize=1000',
    '/NewOrder/deal01?order_status=20&formtype=A&pagesize=1000',
    '/NewOrder/deal01?formtype=A&pagesize=1000',
  ];

  for (const path of paths) {
    try {
      const res = await req({ hostname: FG_HOST, path, method: 'GET',
        headers: { 'Cookie': cookieStr(fgCookies), 'User-Agent': 'Mozilla/5.0',
          'Referer': `https://${FG_HOST}/` }
      });
      const html = res.body;

      // 응답 크기가 너무 작으면 로그인 안 된 것
      if (html.length < 500) {
        log(`  [곳간 ${path}] 응답 너무 짧음 (${html.length}): ${html.slice(0,100)}`);
        continue;
      }

      const orderNums = new Set();
      for (const m of html.matchAll(/PJM\w+/g)) orderNums.add(m[0]);
      log(`  [곳간 ${path}] len=${html.length}, PJM=${orderNums.size}`);

      if (orderNums.size === 0) continue;

      const prodMap = {};
      for (const m of html.matchAll(/([^<>\n\/]{2,40}?)\s*\/\s*(\d+)\s*개/g)) {
        const name = m[1].replace(/<[^>]+>/g,'').trim();
        const qty = parseInt(m[2]);
        if (name.length >= 2 && qty > 0 && !/소계|합계|결제|배송비|선택/.test(name))
          prodMap[name] = (prodMap[name]||0) + qty;
      }

      let totalAmount = 0;
      for (const m of html.matchAll(/([\d,]+)원/g)) {
        const v = parseInt(m[1].replace(/,/g,''));
        if (v >= 1000 && v < 5000000) totalAmount = Math.max(totalAmount, v);
      }

      return { orderCount: orderNums.size, prodMap, totalAmount };
    } catch(e) { log(`  [곳간] ${path} 오류: ${e.message}`); }
  }

  return { orderCount: 0, prodMap: {}, totalAmount: 0 };
}

// ── 포맷 ─────────────────────────────────────────────────
function formatSection(title, data) {
  const { orderCount, prodMap, totalAmount } = data;
  const entries = Object.entries(prodMap)
    .map(([n,v]) => [n, Number(v)||0])
    .filter(([,q]) => q > 0)
    .sort((a,b) => b[1]-a[1]);

  let msg = `${title}\n📦 주문: <b>${orderCount}건</b>`;
  if (totalAmount > 0) msg += `  💰 <b>${won(totalAmount)}</b>`;
  msg += '\n';
  if (entries.length > 0) {
    entries.slice(0,15).forEach(([name,qty]) => { msg += `  • ${name} <b>${qty}개</b>\n`; });
  } else {
    msg += `  (품목 정보 없음)\n`;
  }
  return msg;
}

// ── 명령어 ───────────────────────────────────────────────
let busy = false;
async function handleCommand(cmd, chatId) {
  log(`처리: ${cmd}`);
  if (cmd === '/도움말' || cmd === '도움말') {
    await tgSend(`📋 <b>명령어</b>\n/현황 /어드민 /곳간 /알림 /도움말`, chatId); return;
  }
  if (cmd === '/알림' || cmd === '알림') {
    await tgSend('🔔 gotgan-approve 30초마다 자동 인증대기 체크 중', chatId); return;
  }
  if (busy) { await tgSend('⏳ 조회 중...', chatId); return; }
  busy = true;
  try {
    const now = new Date().toLocaleString('ko-KR', { timeZone: 'Asia/Seoul' });
    if (cmd === '/현황' || cmd === '현황') {
      log('통합 현황 조회...');
      await tgSend('🔍 조회 중...', chatId);
      const [aR, fR] = await Promise.allSettled([getAdminOrders(), getGotganOrders()]);
      const aD = aR.status==='fulfilled' ? aR.value : null;
      const fD = fR.status==='fulfilled' ? fR.value : null;
      let msg = `📊 <b>주문현황</b>  ${now}\n${'─'.repeat(22)}\n\n`;
      msg += aD ? formatSection('🏪 <b>[어드민] 위탁쇼핑몰</b>', aD) : '🏪 조회 실패\n';
      msg += '\n';
      msg += fD ? formatSection('🏬 <b>[곳간] flexgate</b>', fD) : '🏬 조회 실패\n';
      const total = (aD?.totalAmount||0) + (fD?.totalAmount||0);
      msg += `\n${'─'.repeat(22)}\n💵 <b>총 매출: ${won(total)}</b>`;
      if (total > 0) msg += `\n어드민 ${won(aD?.totalAmount||0)} + 곳간 ${won(fD?.totalAmount||0)}`;
      await tgSend(msg, chatId);
      log('발송 완료');
    } else if (cmd === '/어드민' || cmd === '어드민') {
      await tgSend('🔍 어드민 조회...', chatId);
      const d = await getAdminOrders();
      await tgSend(`📊 <b>어드민</b>  ${now}\n\n`+formatSection('🏪',d), chatId);
    } else if (cmd === '/곳간' || cmd === '곳간') {
      await tgSend('🔍 곳간 조회...', chatId);
      const d = await getGotganOrders();
      await tgSend(`📊 <b>곳간</b>  ${now}\n\n`+formatSection('🏬',d), chatId);
    }
  } catch(e) { log(`오류: ${e.message}`); await tgSend(`❌ 오류: ${e.message}`, chatId); }
  finally { busy = false; }
}

// ── 폴링 ─────────────────────────────────────────────────
let lastUpdateId = 0, polling = false;
const CMDS = ['/현황','현황','/어드민','어드민','/곳간','곳간','/도움말','도움말','/알림','알림'];
async function poll() {
  if (polling) return; polling = true;
  try {
    const updates = await tgGetUpdates(lastUpdateId);
    for (const u of updates) {
      lastUpdateId = u.update_id + 1;
      const msg = u.message || u.edited_message;
      if (!msg?.text) continue;
      const text = msg.text.trim().split(' ')[0];
      const chatId = String(msg.chat.id);
      if (chatId !== TG_CHAT) continue;
      log(`수신: "${text}"`);
      if (CMDS.includes(text)) handleCommand(text, chatId);
    }
  } catch(e) { log(`poll 오류: ${e.message}`); }
  finally { polling = false; }
}

log(`🤖 주문현황 봇 v5`);
log(`   명령어: /현황, /어드민, /곳간, /도움말, /알림`);
setInterval(poll, 3000);
poll();
process.on('SIGINT', () => process.exit(0));
process.on('SIGTERM', () => process.exit(0));
